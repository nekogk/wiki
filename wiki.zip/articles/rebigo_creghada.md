
| <big>레비고 츠레가다</big><br>金江南輝 \| Rebigo Creghada | < |
| :--: | -- |
| ![[rebigo_creghada/profile.png\|320]] | < |
| 출생 | [[whuda_era\|우다]] 3년 대한 6일 |
| ^ | [[riris_city\|리리스시]] |
| 거주지 | [[lyuxiqecu_city\|류이케추시]] |
| 국적 | ![[rushikowa_flag.png\|27]] [[rushikowa\|루시코와]] |
| 학력 | [[sluseche_university\|슬루세체대학교]] <sub>(화학 / 학사)</sub> |
| 가족 | 어머니<br>누나 [[daco\|레비고 미체키]] |
| 성격 | ISTP \| 9w1 |

# 개요
---
**레비고 츠레가다**는 [[rushikowa|루시코와]]의 입자화학자이다.