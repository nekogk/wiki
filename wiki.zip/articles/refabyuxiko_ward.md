![[sluqecu_ward]]

| <big>레파뷰이코구</big><br>仮得門区 \| Refabyuxiko Ward | < |
| :-: | :---: |
| ![[map:23965,29731,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-22 |

# 개요
---
**레파뷰이코구**는 [[sluqecu_metropolis|슬루케추시]] 서부에 위치한 구이다.
