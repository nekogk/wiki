| [[xigoshazsha_region\|동경권]] 전철 노선 | < | < | < | < | < |
| :---: | :--: | :--: | :---: | :---: | :-: |
| 일반철도 | < | < | < | < | < |
| [[yezzori_line\|예즈조리선]] | [[zajiwa_line\|자지와선]] |[[shamojesa_line\|샤모제사선]] | [[bicer_line\|비처선]] | [[kone_line\|코네선]] | [[pijibichece_line\|피지비체체선]] |
| [[zshaseme_line\|즈샤세메선]] | [[creresesha_line\|츠레레세샤선]] | [[lega_line\|레가선]] | [[tobajesa_line\|토바제사선]] | [[crereschi_line\|츠레레스치선]] | |
| 도시철도 | < | < | < | < | < |
| [[tobarye_line\|토바례선]] | [[zshashizu_line\|즈샤시주선]] | [[lesayu_line\|레사유선]] | [[hoker_line\|호커선]] | [[bigosefu_line\|비고세푸선]] | [[crererube_line\|츠레레루베선]] |
| [[rushimis_line\|루시미스선]] | [[jiriqe_line\|지리케선]] | [[xigoshabus_line\|이고샤부스선]] | [[cezsefu_line\|체즈세푸선]] | [[bigocrere_line\|비고츠레레선]] | [[bigorube_line\|비고루베선]] |
| 경전철 | < | < | < | < | < |
| [[hatarechetu_line\|하타레체투선]] | [[nijere_line\|니제레선]] | [[pesamu_line\|페사무선]] | [[lano_line\|라노선]] | [[zshibise_line\|즈시비세선]] | [[remasesha_line\|레마세샤선]] |
| [[sachiseme_line\|사치세메선]] | [[whohercache_line\|워허차체선]] | [[baxyaeru_line\|바야에루선]] | [[sechicaspe_line\|세치차스페선]] | [[rexajerche_line\|레아저체선]] | [[mutu_tram\|무투트램]] |
| [[whishes_line\|위셰스선]] | [[rurikaxi_line\|루리카이선]] |  [[smijiseda_line\|스미지세다선]] |  [[wezwhori_line\|웨즈워리선]] | [[bipejoda_line\|비페조다선]] |  [[haritome_line\|하리토메선]] |
|  [[whopuwhili_line\|워푸윌리선]] | [[yuwhigo_line\|유위고선]] | [[hanyaris_line\|하냐리스선]] | [[jesajig_line\|제사지그선]] | [[rubesefu_line\|루베세푸선]] | [[aroce_line\|아로체선]] |
| [[miquwhona_line\|미쿠워나선]] | [[remaxili_line\|레마일리선]] | | | | |
