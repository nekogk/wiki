![[sluqecu_ward]]

| <big>세시세푸구</big><br>浅浦区 \| Seshisefu Ward | < |
| :---: | :---: |
| ![[map:39045,44469,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-27 |

# 개요
---
**세시세푸구**는 [[sluqecu_metropolis|슬루케추시]] 북부에 위치한 구이다.
