![[sluqecu_ward]]

| <big>게예사처구</big><br>香振区 \| Gheyesacer Ward | < |
| :-: | :---: |
| ![[map:37434,36528,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-26 |

# 개요
---
[[sluqecu_metropolis|슬루케추시]] 북부에 위치한 구.
