![[sluqecu_ward]]

| | ![[ghashido_ward_emblem_white.png\|48]] |<big>가시도구</big><br>虚陽区 \| Ghashido Ward | < |
| :-: | ---: | :-- | :---: |
| ![[map:22596,33908,-2\|400x160]] | < | < | < |
| 구청 소재지 | < | < | 율레스가 1-2 |
| 경시현 | < | < | [[sluqecu_metropolis\|슬루케추시]] |
| 하위 행정구역 | < | < | 14가 |
| 지역번호 | < | < | 011-01 |

# 개요
---
**가시도구**는 [[sluqecu_metropolis|슬루케추시]] 도심부에 위치한 구로, 동쪽으로는 [[shishiceso_ward|시시체소구]], 서쪽으로는 [[refabyuxiko_ward|레파뷰이코구]], 북쪽으로는 [[shitobu_ward|시토부구]]와 [[sasgri_ward|사스그리구]], 남쪽으로는 [[pijizu_ward|피지주구]]와 [[whohercache_ward|워허차체구]]를 접하고 있다. 구의 중심에는 [[sebucheqa_stream|세부체카천]]이 흐른다.

과거에는 서구로도 불렸으며, 현재는 시시체소구의 하타레체투 도심가의 확장으로 가시도구의 남쪽은 도심화가 많이 진행된 상태이다.