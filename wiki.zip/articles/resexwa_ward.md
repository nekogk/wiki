![[sluqecu_ward]]

| <big>레세와구</big><br>仕湾区 \| Resexwa Ward | < |
| :---: | :---: |
| ![[map:14907,38829,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-19 |

# 개요
---
**레세와구**는 [[sluqecu_metropolis|슬루케추시]] 남부에 위치한 구이다.
