![[sluqecu_ward]]

| <big>사스그리구</big><br>司㦮区 \| Sasgri Ward | < |
| :---: | :---: |
| ![[map:26452,33373,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-07 |

# 개요
---
**사스그리구**는 [[sluqecu_metropolis|슬루케추시]] 중부에 위치한 구이다.
