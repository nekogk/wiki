
| <big>하타레체투4가역</big><br>初地四番街駅 \| Hatarechetu 4th street Station | < | < |
| :--: | :-: | :-: |
| <small>[[rubezujer_station\|루베주저]] 방면</small><br>[[metropolitan_city_hall_station\|시청]]<br>← 0.6 km | ![[zshashizu_line_icon.png\|32]]<br><small>[[zshashizu_line\|즈샤시주선]]</small><br><small>(SQ0251)</small> | <small>[[remaxili_station\|레마일리]] 방면</small><br>[[shishiceso_ward_office_station\|시시체소구청]]<br>0.8 km → |
| <small>[[shizomacho_station\|시조마초]] 방면</small><br>[[central_bank_station\|중앙은행]]<br>← 0.5 km | ![[crererube_line_icon.png\|32]]<br><small>[[crererube_line\|츠레레루베선]]</small><br><small>(SQ0662)</small> | <small>[[eshuwhi_station\|에슈위]] 방면</small><br>[[hatarechetu_park_station\|하타레체투공원]]<br>0.6 km → |
| ![[map:21771,36080,-1\|400x160]] | < | < |
| 주소 | < | < |
| [[sluqecu_metropolis\|슬루케추시]] [[shishiceso_ward\|시시체소구]] | < | < |
| [[zshashizu_line\|즈샤시주선]] | 하타레체투 4가 1-5 | < |
| [[crererube_line\|츠레레루베선]] | 유웨즈 3가 1-42 | < |
| 운영기관 | < | < |
| [[zshashizu_line\|즈샤시주선]] | [[sluqecu_metropolis\|슬루케추시]] | < |
| [[crererube_line\|츠레레루베선]] | ^ | < |
| 개업일 | < | < |
| [[zshashizu_line\|즈샤시주선]] | [[rimi_era\|리미]] 26년 상강 17일 | < |

# 개요
---
**하타레체투4가역**은 [[sluqecu_metropolis|슬루케추시]] 지하철 [[zshashizu_line|즈샤시주선]]과 [[crererube_line|츠레레루베선]]의 환승역이다.

# 역 정보
---
| ![[hatarechetu_4th_street_station_map.png|480]] |
| :-: |
| 역 안내도 |
