![[sluqecu_ward]]

| <big>세치차스페구</big><br>済座区 \| Sechicaspe Ward | < |
| :--: | :---: |
| ![[map:33987,23448,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-24 |

# 개요
---
**세치차스페구**는 [[sluqecu_metropolis|슬루케추시]] 서북부에 위치한 구이다.
