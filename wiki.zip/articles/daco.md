| <big>다코</big><br> \| Daco | < |
| :-: | --- |
| ![[daco.png\|320]] | < |
| 본명 | 레비고 미체키(金江来華) |
| 출생 | [[whuda_era\|우다]] 원년 우수 19일 |
| ^ | [[riris_city\|리리스시]] |
| 거주지 | [[sluqecu_metropolis\|슬루케추시]] [[recadesae_ward\|레차데사에구]] |
| 국적 | ![[rushikowa_flag.png\|27]] [[rushikowa\|루시코와]] |
| 학력 | 중학학력인정제도<sub> (합격)</sub><br>[[sluqecu_university\|슬루케추대학교]] <sub>(도시공학 · 컴퓨터공학 / 학사)</sub> |
| 신체 | 171cm \| 51kg |
| 가족 | 어머니<br>남동생 [[rebigo_creghada\|레비고 츠레가다]] |
| 성격 | INTP \| 9w8 |

# 개요
---
[[rushikowa|루시코와]]의 도시분석가.

# 생애
---
[[riris_city|리리스시]]에서 태어나 리리스시에서 소학교를 졸업한 리리스시 토박이이다. 중학교는 정체화 시기의 방황으로 2학년때 자퇴한 이후, 학력인정제도를 통해 대학교에 진학했다.