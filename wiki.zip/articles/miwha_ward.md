![[sluqecu_ward]]

| <big>미와구</big><br>㒱華区 \| Miwha Ward | < |
| :---: | :---: |
| ![[map:38467,58725,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-30 |


# 개요
---
[[sluqecu_metropolis|슬루케추시]] 동북부에 위치한 구.