![[coroji_metropolis]]

| | ![[rushisewhu_metropolis_emblem_white.png\|48]] | <big>루시세우시</big><br>㒱湖京 \| Rushisewhu Metropolis | < |
| :-: | ---: | :-- | :---: |
| 주 | < | < | [[dechi_state\|데치주]] |

# 개요
---
**루시세우시**는 [[ectenium|연본국]]의 최대 도시이자 수도로, [[coroji|삼록권]] 전체의 발원지라는 특성에 의해 문화적으로 중요도가 매우 높은 도시 중 하나이다. 여러모로 일본의 교토나 한국의 경주와 비슷하다.
