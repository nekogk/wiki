
| | ![[riris_city_emblem_white.png\|48]] | <big>리리스시</big><br>旧雲市 \| Riris City | < |
| :-: | -: | - | :-: |
| 주 | < | < | [[hayane_state\|하야네주]] |
| 하위 행정구역 | < | < | 9구 |
| 인구 | < | < | 370만명 |

# 개요
---
**리리스시**는 [[rushikowa|루시코와]] [[hayane_state|하야네주]] 북부에 위치한 해안도시이다.