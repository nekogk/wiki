![[sluqecu_ward]]

| <big>아스리뉴구</big><br>広女区 \| Asrinyu Ward | < |
| :-: | :---: |
| ![[map:23074,41922,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-13 |
# 개요
---
[[sluqecu_metropolis|슬루케추시]] 동남부에 위치한 구.