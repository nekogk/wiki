![[sluqecu_ward]]

| <big>서코시구</big><br>舞名区 \| Serkoshi Ward | < |
| :-: | :---: |
| ![[map:12633,44424,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-16 |

# 개요
---
**서코시구**는 [[sluqecu_metropolis|슬루케추시]] 동남부에 위치한 구이다.
