![[sluqecu_ward]]

| <big>레마세샤구</big><br>満港区 \| Remasesha Ward | < |
| :---: | :---: |
| ![[map:30158,46776,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-11 |

# 개요
---
**레마세샤구**는 [[sluqecu_metropolis|슬루케추시]] 동부에 위치한 구이다.
