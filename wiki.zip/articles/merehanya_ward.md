![[sluqecu_ward]]

| <big>메레하냐구</big><br>寒滩区 \| Merehanya Ward | < |
| :---: | :---: |
| ![[map:34671,47164,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-09 |

# 개요
---
**메레하냐구**는 [[sluqecu_metropolis|슬루케추시]] 동부에 위치한 구이다.
