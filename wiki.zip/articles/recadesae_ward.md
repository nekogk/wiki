![[sluqecu_ward]]

| <big>레차데사에구</big><br>竜岩区 \| Recadesae Ward | < |
| :-: | :--: |
| ![[map:27424,28997,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 하위 행정구역 | 12가 |
| 지역번호 | 011-21 |


# 개요
---
**레차데사에구**는 [[sluqecu_metropolis|슬루케추시]] 서부에 위치한 구이다.