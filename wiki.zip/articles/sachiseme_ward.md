![[sluqecu_ward]]

| <big>사치세메구</big><br>計海区 \| Sachiseme Ward | < |
| :---: | :---: |
| ![[map:35568,41984,-2\|400x160]] | < |
| 경시현 | [[sluqecu_metropolis\|슬루케추시]] |
| 지역번호 | 011-28 |

# 개요
---
**사치세메구**는 [[sluqecu_metropolis|슬루케추시]] 북부에 위치한 구이다.